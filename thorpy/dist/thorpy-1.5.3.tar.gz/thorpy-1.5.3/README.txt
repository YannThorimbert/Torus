# Thorpy-1.5.3

ThorPy is a free GUI library intended for use with pygame. Just extract thorpy folder for use, or see installation explanations on http://www.thorpy.org.

Changelog for ThorPy 1.5.3:

#stick_to is now a method of ghost
#added colorkey to Image element
#limvals is now public attribute of sliders
#make_choices accept personnalized elements
#launch_binary_choice added to wrappers functions
#inserter can have numeric input only using numeric variable
#image and imageframe updated to avoid potential bugs
#corrected potential bug of Image element